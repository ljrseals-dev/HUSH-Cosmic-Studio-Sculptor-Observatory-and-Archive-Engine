#include "hush/EngineBridge.hpp"
#include <algorithm>
#include <cmath>
namespace hush {
void EngineBridge::setMasterGain(float gain) noexcept {
    gain_.store(std::clamp(gain, 0.0f, 4.0f), std::memory_order_relaxed);
}
void EngineBridge::setLimiterEnabled(bool enabled) noexcept {
    limiter_enabled_.store(enabled, std::memory_order_relaxed);
}
void EngineBridge::postProcess(float* samples, std::size_t frames, unsigned channels) noexcept {
    if (samples == nullptr || channels == 0) { peak_.store(0.0f, std::memory_order_relaxed); return; }
    const std::size_t count = frames * static_cast<std::size_t>(channels);
    const float gain = gain_.load(std::memory_order_relaxed);
    const bool limit = limiter_enabled_.load(std::memory_order_relaxed);
    float peak = 0.0f;
    for (std::size_t i = 0; i < count; ++i) {
        float value = samples[i] * gain;
        if (limit) value = std::clamp(value, -1.0f, 1.0f);
        samples[i] = value;
        peak = std::max(peak, std::abs(value));
    }
    peak_.store(peak, std::memory_order_relaxed);
}
float EngineBridge::outputPeak() const noexcept { return peak_.load(std::memory_order_relaxed); }
}
