#include <X11/Xlib.h>
#include <string>
int main() {
    Display* d = XOpenDisplay(nullptr);
    if (!d) return 1;
    const int s = DefaultScreen(d);
    Window w = XCreateSimpleWindow(d, RootWindow(d, s), 30, 30, 1180, 720, 1,
                                   WhitePixel(d, s), 0x080912);
    XStoreName(d, w, "HUSH Cosmic Studio | Sculptor • Observatory • Archive & Engine");
    XSelectInput(d, w, ExposureMask | KeyPressMask);
    XMapWindow(d, w);
    GC gc = XCreateGC(d, w, 0, nullptr);
    bool running = true;
    while (running) {
        XEvent e; XNextEvent(d, &e);
        if (e.type == KeyPress) running = false;
        if (e.type == Expose) {
            XSetForeground(d, gc, 0x9B4DFF);
            XDrawString(d, w, gc, 30, 40, "HUSH COSMIC STUDIO", 18);
            XSetForeground(d, gc, 0x00DDF5);
            XDrawString(d, w, gc, 30, 78, "SCULPTOR", 8);
            XDrawString(d, w, gc, 430, 78, "OBSERVATORY", 11);
            XDrawString(d, w, gc, 850, 78, "ARCHIVE & ENGINE", 16);
            XSetForeground(d, gc, 0xB7C4D8);
            XDrawString(d, w, gc, 30, 120, "UI shell / layout concept only — production audio integration remains outstanding.", 75);
            XSetForeground(d, gc, 0x171A28);
            XFillRectangle(d, w, gc, 20, 145, 350, 520);
            XFillRectangle(d, w, gc, 390, 145, 390, 520);
            XFillRectangle(d, w, gc, 800, 145, 350, 520);
            XSetForeground(d, gc, 0x9B4DFF);
            XDrawString(d, w, gc, 40, 180, "Arrangement / Tracks / Mixer", 28);
            XSetForeground(d, gc, 0x00DDF5);
            XDrawString(d, w, gc, 415, 180, "Cosmic Observatory", 19);
            XSetForeground(d, gc, 0xF044C8);
            XDrawString(d, w, gc, 825, 180, "Local Library / Engine Health", 28);
        }
    }
    XFreeGC(d, gc); XDestroyWindow(d, w); XCloseDisplay(d); return 0;
}
