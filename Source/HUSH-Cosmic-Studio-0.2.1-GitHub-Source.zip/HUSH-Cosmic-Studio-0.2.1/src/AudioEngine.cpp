#include "hush/AudioEngine.hpp"
#include <algorithm>
namespace hush {
void AudioEngine::setMasterGain(float gain) noexcept {
    master_gain_.store(std::clamp(gain, 0.0f, 4.0f), std::memory_order_relaxed);
}
void AudioEngine::setLimiterEnabled(bool enabled) noexcept { bridge_.setLimiterEnabled(enabled); }
void AudioEngine::process(float* interleaved, std::size_t frames, unsigned channels) noexcept {
    bridge_.setMasterGain(master_gain_.load(std::memory_order_relaxed));
    bridge_.postProcess(interleaved, frames, channels);
}
float AudioEngine::outputPeak() const noexcept { return bridge_.outputPeak(); }
}
