#include <algorithm>
#include <cstddef>
#if defined(_WIN32)
#define HUSH_EXPORT extern "C" __declspec(dllexport)
#else
#define HUSH_EXPORT extern "C" __attribute__((visibility("default")))
#endif
// Demonstration ABI only; this is not a VST3 or LV2 plugin.
HUSH_EXPORT const char* hush_module_name() { return "HUSH Demo Gain"; }
HUSH_EXPORT void hush_module_process(float* samples, std::size_t count, float gain) {
    if (samples == nullptr) return;
    gain = std::clamp(gain, 0.0f, 4.0f);
    for (std::size_t i = 0; i < count; ++i) samples[i] *= gain;
}
