#pragma once
#include <atomic>
#include <cstddef>
namespace hush {
class EngineBridge {
public:
    void setMasterGain(float gain) noexcept;
    void setLimiterEnabled(bool enabled) noexcept;
    void postProcess(float* interleaved, std::size_t frames, unsigned channels) noexcept;
    [[nodiscard]] float outputPeak() const noexcept;
private:
    std::atomic<float> gain_{1.0f};
    std::atomic<bool> limiter_enabled_{false};
    std::atomic<float> peak_{0.0f};
};
}
