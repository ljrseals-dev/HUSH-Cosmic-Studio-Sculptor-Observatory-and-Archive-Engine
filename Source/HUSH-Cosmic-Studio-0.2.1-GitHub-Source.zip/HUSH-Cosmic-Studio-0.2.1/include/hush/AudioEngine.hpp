#pragma once
#include "hush/EngineBridge.hpp"
#include <atomic>
#include <cstddef>
namespace hush {
class AudioEngine {
public:
    void setMasterGain(float gain) noexcept;
    void setLimiterEnabled(bool enabled) noexcept;
    void process(float* interleaved, std::size_t frames, unsigned channels) noexcept;
    [[nodiscard]] float outputPeak() const noexcept;
private:
    std::atomic<float> master_gain_{1.0f};
    EngineBridge bridge_;
};
}
