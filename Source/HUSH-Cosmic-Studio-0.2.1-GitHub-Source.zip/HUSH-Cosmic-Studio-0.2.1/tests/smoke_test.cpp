#include "hush/AudioEngine.hpp"
#include <cmath>
#include <iostream>
int main() {
    hush::AudioEngine engine;
    engine.setMasterGain(0.5f);
    float buffer[] = {1.0f, -0.5f, 0.25f, -1.0f};
    engine.process(buffer, 2, 2);
    const bool ok = std::abs(buffer[0] - 0.5f) < 1e-6f &&
                    std::abs(buffer[1] + 0.25f) < 1e-6f &&
                    std::abs(engine.outputPeak() - 0.5f) < 1e-6f;
    if (!ok) { std::cerr << "HUSH smoke test failed\n"; return 1; }
    std::cout << "HUSH smoke test passed\n";
    return 0;
}
