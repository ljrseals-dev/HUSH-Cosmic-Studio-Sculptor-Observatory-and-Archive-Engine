# Dependencies

- CMake 3.16+
- C++20 compiler
- Optional UI: Linux/X11 development headers and libraries
- Core smoke test uses no third-party runtime library.
- Build does not download dependencies.
