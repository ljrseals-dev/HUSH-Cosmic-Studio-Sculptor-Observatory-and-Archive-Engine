# Security and privacy

- This bundle contains no telemetry, analytics, crash-upload, update-check, remote-configuration, or runtime network code.
- CMake does not fetch or bootstrap dependencies.
- Audio processing uses caller-owned buffers and atomics for simple controls; it does not allocate in the example `process()` path.
- The sample module is not sandboxed. Load only code you trust.
- No independent security audit is claimed.
