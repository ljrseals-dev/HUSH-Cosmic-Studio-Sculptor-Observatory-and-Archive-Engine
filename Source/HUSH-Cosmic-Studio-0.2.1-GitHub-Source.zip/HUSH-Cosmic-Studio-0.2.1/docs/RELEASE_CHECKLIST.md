# GitHub release checklist

- [ ] Review the source and confirm it matches the intended repository branch.
- [ ] Build with the target compiler and capture the actual output.
- [ ] Run `ctest --test-dir build --output-on-failure` and attach the real result.
- [ ] If building the UI, verify X11 launch and close behavior on target Linux hardware.
- [ ] Confirm license and third-party attribution before publication.
- [ ] Do not describe the demo module as VST3/LV2 or the UI shell as a complete DAW.
- [ ] Publish only after a human maintainer reviews the diff.
